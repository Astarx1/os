#include "func.h"
#include "shell.h"
int main(int argc, char ** argv) {
	start();
	return 0;
}